# TextBoxDemo for SSD1306

This project uses an 8-dot font.   
The maximum number of characters that can be displayed is 16 characters.   
By using the ssd1306_display_text_box function, it is possible to display more than 16 characters.   


